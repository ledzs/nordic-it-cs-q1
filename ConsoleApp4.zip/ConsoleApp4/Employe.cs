﻿namespace ConsoleApp4
{
	class Employe : Person
	{
		public string Company { get; set; }
		public new string Description =>
			$"{base.Description}, company {Company}"; //base берет Description из базового класса
	}
}
