﻿namespace ConsoleApp4
{
	class Person
	{
		public byte Age { get; set; }

		public string Name { get; set; }

		public string Description
		{
			get
			{
				return $"Name is {Name}, age is {Age}";
			}
		}
	}
}
