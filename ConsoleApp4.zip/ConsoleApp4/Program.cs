﻿using System;

namespace ConsoleApp4
{
	class Program
	{
		static void Main(string[] args)
		{
			BaseDocument doc1 = new BaseDocument("Book", "123123", DateTime.Parse("2012-02-03"))
			{
			};

			doc1.WriteToConsole();

			Passport doc2 = new Passport("123123", DateTime.Parse("2012-02-03"), "Russia", "Ivan")
			{
			};

			doc2.WriteToConsole();

			//Console.WriteLine(doc1);
			//Console.WriteLine(doc2);
			Console.ReadKey();

			/*
			Person person = new Person()
			{
				Name = "Person one",
				Age = 21
			};
			Employe employe = new Employe()
			{
				Name = "Employe one",
				Age = 24,
				Company = "Company"
			};
			Console.WriteLine(person.Description);
			Console.WriteLine(employe.Description);
			Console.ReadKey();
			*/

		}
	}
}
