﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Reminder.Storage.Memory.Tests")]
[assembly: InternalsVisibleTo("Reminder.Domain.Tests")]
[assembly: InternalsVisibleTo("Reminder.WebApi.Tests")]
