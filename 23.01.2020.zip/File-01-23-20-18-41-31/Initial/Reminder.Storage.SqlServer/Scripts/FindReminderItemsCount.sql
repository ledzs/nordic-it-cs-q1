﻿SELECT COUNT(RI.Id) AS [Count] FROM [ReminderItem] RI {filter}
