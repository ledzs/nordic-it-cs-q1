﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Reminder.Storage.SqlServer.Tests")]
