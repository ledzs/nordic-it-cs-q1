CREATE DATABASE Lesson26;

USE Lesson26;
GO


CREATE TABLE CreditCard(
    CardNumber      CHAR(20) NOT NULL,
    HolderName      VARCHAR(50) NULL,
    ExpirationMonth TINYINT NOT NULL,
    ExpirationYear  SMALLINT NOT NULL,
    SecurityCode    SMALLINT NOT NULL,
);

SELECT * FROM CreditCard;

INSERT INTO CreditCard (HolderName, CardNumber, ExpirationYear, ExpirationMonth, SecurityCode)
VALUES ('Ivan', '0000-1111-2222-3333', 21, 09, 123);

INSERT INTO CreditCard(HolderName, CardNumber, ExpirationYear, ExpirationMonth, SecurityCode)
VALUES  ('Ivan','0000-1111-2222-3333', 20, 09, 123),
        ('Ivan','0000-1111-2222-3333', 20, 09, 123),
        ('Ivan','0000-1111-2222-3333', 20, 09, 123);