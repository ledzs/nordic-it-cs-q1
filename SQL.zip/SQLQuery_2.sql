CREATE DATABASE PostOffice;

USE PostOffice;
GO

CREATE TABLE PostalSending(

    SenderName              VARCHAR(50),
    ReceiverName            VARCHAR(50),
    DocumentTitle           CHAR(20),
    NumberOfPages           SMALLINT,
    SendingDate             DATETIME2,
    ExpectedReceivingDate   DATETIME2,
);

SELECT * FROM PostalSending;

INSERT INTO PostalSending 
VALUES ('Ivan', 'Alex', 'Azbuka', 30, '2004-05-23T14:25:10','2005-05-23T14:25:10'),
        ('Victor', 'Alex', 'Order', 30, '2004-05-23T14:25:10','2006-05-23T14:25:10');

drop table PostalSending;

