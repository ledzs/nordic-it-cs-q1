﻿using System;
using Calculator.Figure;
using Calculator.Operation;

namespace classwork07._11._19
{
	class Program
	{
		
		static void Main(string[] args)
		{

			double radius = 13;
			Circle circle = new Circle(radius);
			Console.WriteLine($"Radius: {radius}, Perimeter: {CircleOperation.Perimeter(radius)}, Area: {CircleOperation.Area(radius)}");

			double side = 5;
			Square square = new Square(side);
			Console.WriteLine($"Side: {side}, Square Perimeter: {SquareOperation.Perimeter(side)}, square area: {SquareOperation.Area(side)}");
			
			Console.ReadKey();
			
		}

		
		
		
	}

}
