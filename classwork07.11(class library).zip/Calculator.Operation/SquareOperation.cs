﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Calculator.Operation
{
	public class SquareOperation
	{
		public static double Perimeter(double side)
		{
			double perimeter = 4 * side;
			return perimeter;
		}

		public static double Area(double side)
		{
			double area = Math.Pow(side, 2);
			return area;
		}
	}
}
