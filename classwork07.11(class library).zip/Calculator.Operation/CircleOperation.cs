﻿using System;

namespace Calculator.Operation
{
	public class CircleOperation
	{
		public static double Perimeter(double radius)
		{
			double perimeter = 2 * Math.PI * radius;
			return perimeter;
		}

		public static double Area(double radius)
		{
			double area = Math.Pow(Math.PI * radius, 2);
			return area;
		}
	}
}
