﻿namespace ConsoleApp5
{
	public class RandomDataGeneratorNew
	{
		public RandomDataGeneratorNew(int dataSize, int i)
		{
			this.dataSize = dataSize;
			this.totalBytes = i;
		}

		public int dataSize { get; set; }
		public int totalBytes { get; set; }
	}
}
