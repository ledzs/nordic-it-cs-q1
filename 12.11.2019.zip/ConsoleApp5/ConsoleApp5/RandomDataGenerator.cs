﻿using System;

namespace ConsoleApp5
{
	public class RandomDataGenerator
	{
		public event EventHandler<RandomDataGeneratorNew> RandomDataGenerating;
		public event EventHandler RandomDataGenerated;

		public byte[] GetRandomData(int dataSize, int bytesDoneToRaiseEvent)
		{
			if (dataSize <=0)
			{
				throw new ArgumentOutOfRangeException(nameof (dataSize));
			}

			if (bytesDoneToRaiseEvent <= 0)
			{
				throw new ArgumentOutOfRangeException(nameof(bytesDoneToRaiseEvent));
			}

			var bytes = new byte[dataSize];
			var random = new Random();

			for (int i = 0; i < bytes.Length; i++)
			{
				bytes[i] = (byte)random.Next();

				if (i % bytesDoneToRaiseEvent == 0)
				{
					RandomDataGenerating?.Invoke(this, new RandomDataGeneratorNew(dataSize, i));
				}
			}

			RandomDataGenerated?.Invoke(this, null);
			return bytes;
		}
		
	}
}
