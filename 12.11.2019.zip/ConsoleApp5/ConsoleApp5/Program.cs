﻿using System;
using System.IO;

namespace ConsoleApp5
{
	//public delegate void RandomDataGeneratedHandler(int bytesDone, int totalBytes);

	internal class Program
	{
		static void Main(string[] args)
		{
			var generator = new RandomDataGenerator();
			generator.RandomDataGenerating += OnRandomDataGenerating;
			generator.RandomDataGenerated += OnRandomDataGenerated;
			var data = generator.GetRandomData(dataSize: 8, bytesDoneToRaiseEvent: 3);
			Console.ReadKey();
		}

		
		private static void OnRandomDataGenerating(object generator, RandomDataGeneratorNew e)
		{
			Console.WriteLine($"Generate {e.dataSize}, data of {e.totalBytes}");
		}

		private static void OnRandomDataGenerated(object sender, EventArgs e)
		{
			Console.WriteLine("Data Generated");
		}
		
	}
	
}
