﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace ConsoleApp8
{
	class Program
	{
		static void Main(string[] args)
		{
			using (ErrorList errorList = new ErrorList("Error!", new List<string>()))
			{
				errorList.Add("one");
				errorList.Add("two");

				foreach (var item in errorList)
				{
					Console.WriteLine($"{item}");
				}

			}
			Console.ReadKey();
		}
	}
	
}
