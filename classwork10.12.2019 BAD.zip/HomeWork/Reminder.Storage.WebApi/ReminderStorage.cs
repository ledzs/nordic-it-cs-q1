﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.Json;

namespace Reminder.Storage.WebApi
{
    public class ReminderStorage : IReminderStorage
    {
        private readonly HttpClient _client;
        public ReminderStorage(HttpClient client)
        {
            _client = client;
        }

        //POST api/reminders
        public void Add(ReminderItem item)
        {
            var json = JsonSerializer.Serialize(item);
            var request = new HttpRequestMessage(HttpMethod.Post, "/api/reminders")
            {
                Content = new StringContent(json, Encoding.UTF8, "application/json")
            };

            var response = _client.SendAsync(request)
                .GetAwaiter()
                .GetResult();

            if (response.StatusCode != HttpStatusCode.Created)
            {
                throw new InvalidOperationException(
                    $"Operation failed with code: {response.StatusCode}");
            }
        }

        public List<ReminderItem> FindBy(ReminderItemFilter filter)
        {
            
        }

        public ReminderItem FindById(Guid id)
        {
            var response = Execute($"/api/reminders/{id}", HttpMethod.Get);
            response.EnsureSuccessStatusCode();

            var json = response.Content.ReadAsStringAsync()
                .GetAwaiter()
                .GetResult();
            var item = JsonSerializer.Deserialize<List<ReminderItem>>(json);
            return item;
        }

        public void Update(ReminderItem item)
        {
            var content = CreateContent(item);
            var response = Execute($"/api/reminders/{item.Id}", HttpMethod.Put, content);
            if (response.StatusCode != HttpStatusCode.OK)
            {
                throw new InvalidOperationException(
                    $"Operation failed with code: {response.StatusCode}");
            }
        }

        private StringContent CreateContent(ReminderItem item)
        {
            var json = JsonSerializer.Serialize(item);
            return new StringContent(json, Encoding.UTF8, "application/json");
        }
        private HttpResponseMessage Execute(
            string url,
            HttpMethod method,
            StringContent content = default)
        {
            var request = new HttpRequestMessage(method, url)
            {
                Content = content
            };

            var response = _client.SendAsync(request)
                .GetAwaiter()
                .GetResult();

            return response;
        }
        
    }
    public static class Converter
    {
        public static StringContent ToContent<T>(this T item)
        {
            var json = JsonSerializer.Serialize<T>(item);
            return new StringContent(json, Encoding.UTF8, "application/json");
        }

        public static T ToObject<T>(this HttpContent content)
        {
            var json = content.ReadAsStringAsync()
                .GetAwaiter()
                .GetResult();
            var result = JsonSerializer.Deserialize<T>(json);
            return result;
        }
    }
}
