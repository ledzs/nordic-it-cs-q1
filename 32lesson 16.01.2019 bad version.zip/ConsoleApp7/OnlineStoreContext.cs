﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ConsoleApp7
{
	class OnlineStoreContext : DbContext
	{
		private const string ConnectionString =
			"Server = tcp:shadow-art.database.windows.net,1433;" +
			"Initial Catalog=reminder;" +
			"Persist Security Info = False;" +
			"User ID = e_kotegov@shadow-art;" +
			"Password = SRFMmtC715qv3EmL9n3w;" +
			"Encrypt=True;";
		public DbSet<Product> Products { get; set; }
		public DbSet<Customer> Customers { get; set; }
		public DbSet<Order> Orders { get; set; }
		public DbSet<OrderLine> OrderLines { get; set; }

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			OnCustomerModelCreating(modelBuilder.Entity<Customer>());

		}

		private void OnCustomerModelCreating(EntityTypeBuilder<Customer> builder)
		{
			builder.Property(customer => customer.Id).ValueGeneratedOnAdd();
			builder.Property(customer => customer.Name).HasMaxLength(128);

		}
		private void OnCustomerModelCreating(EntityTypeBuilder<Product> builder)
		{
			builder.Property(product => product.Id).ValueGeneratedOnAdd();
			builder.Property(product => product.Name).HasMaxLength(128);
			builder.Property(product => product.Price);
		}

		private void OnEntityModelCreating(EntityTypeBuilder<OrderLine> builder)
		{
			builder.Property(line => line.Count);
			builder.Property(line => line.OrderId);
		}

		private void OnEntityModelCreating(EntityTypeBuilder<Order> builder)
		{
			builder.Property(order => order.Id).ValueGeneratedOnAdd();
			builder.Property(order => order.OrderDate);
			builder.Property(order => order.Discount);

			builder
				.HasOne(order => order.Customer)
				.WithMany(customer => customer.Orders);

		}
	}
}
