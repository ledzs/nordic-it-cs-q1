﻿using System;
using System.Collections.Generic;

namespace ConsoleApp7
{
	class Product
	{
		public int Id { get; private set; }
		public string Name { get; set; }
		public decimal Price { get; set; }
		public ICollection<OrderLine> OrderLines { get; private set; }
		public Product(int id, string name, decimal price)
		{
			Name = name;
			Price = price;
			OrderLines = new List<OrderLine>();
		}
	}
	class Customer
	{
		public Customer(int id, string name)
		{
			this.Id = id;
			Name = name;
		}

		public int Id { get; private set; }
		public string Name { get; set; }
		public object Orders { get; internal set; }

		public ICollection<Order>();
	}
	
	class Order
	{
		private int v1;
		private DateTimeOffset utcNow;
		private decimal v2;

		public Order(int v1, DateTimeOffset utcNow, decimal v2, Customer customer)
		{
			this.v1 = v1;
			this.utcNow = utcNow;
			this.v2 = v2;
			Customer = customer;
		}

		public Order(int id, int customerId, DateTimeOffset orderDate, decimal? discount, Customer customer, ICollection<OrderLine> orderLines)
		{
			this.Id = id;
			CustomerId = customerId;
			OrderDate = orderDate;
			Discount = discount;
			Customer = customer;
			OrderLines = orderLines;
		}

		public int Id { get; set; }
		public int CustomerId { get; private set; }
		public DateTimeOffset OrderDate { get; private set; }
		public decimal? Discount { get; private set; }
		public Customer Customer { get; private set; }
		public ICollection<OrderLine> OrderLines { get; private set; }

		public decimal TotalSum()
		{
			var sum = 0.0m;

			foreach (var line in OrderLines)
			{
				sum += line.Sum();
			}

			return sum * (1 - Discount.GetValueOrDefault());

		}
	}
	class OrderLine
	{
		private int v1;
		private int v2;
		private Product product;

		public OrderLine(int orderId, int customerId, int count)
		{
			OrderId = orderId;
			CustomerId = customerId;
			Count = count;
		}

		public OrderLine(int v1, int v2, Product product)
		{
			this.v1 = v1;
			this.v2 = v2;
			this.product = product;
		}

		public int OrderId { get; private set; }
		public int CustomerId { get; private set; }
		public int Count { get; private set; }

		

	}
	class Program
	{
		static void Main(string[] args)
		{
			var product = new Product(1, "Notebook", 20_000);
			var customer = new Customer(1, "Ivan");
			var order = new Order(1, DateTimeOffset.UtcNow, 0.12m, customer);
			order.OrderLines.Add(new OrderLine(1, 2, product));



			Console.WriteLine(order.TotalSum());
			Console.WriteLine("Completed");
		}
	}
}
