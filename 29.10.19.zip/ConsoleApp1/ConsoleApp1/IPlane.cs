﻿namespace ConsoleApp1
{
        interface IPlane
        {
            byte EnginesCount { get; set; }
            int MaxHeight { get; set; }
            int CurrentHeight { get; set; }
            void WriteAllProperties();
        }
   
}
