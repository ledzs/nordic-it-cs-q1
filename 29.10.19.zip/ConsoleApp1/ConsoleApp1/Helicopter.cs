﻿using System;

namespace ConsoleApp1
{
    class Helicopter
    {
        public byte BladesCount { get; private set; }
        public int CurrentHeight { get; set; }
        public int MaxHeight { get; set; }

        public Helicopter(int maxHeight, byte bladesCount)
        {
            MaxHeight = maxHeight;
            BladesCount = bladesCount;
            CurrentHeight = 0;
            Console.WriteLine("It's a helicopter, welcome aboard!");
        }

        public void WriteAllProperties()
        {
            Console.WriteLine($"BladesCount:   {BladesCount} \n " +
                $"CurrentHeight:   {CurrentHeight} \n" +
                $"MaxHeight:   {MaxHeight}");
        }

    }
}
