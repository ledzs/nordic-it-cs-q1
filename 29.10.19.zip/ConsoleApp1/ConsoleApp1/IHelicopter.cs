﻿namespace ConsoleApp1
{
    interface IHelicopter
    {
        byte BladesCount { get; set; }
        int CurrentHeight { get; set; }
        int MaxHeight { get; set; }
        void WriteAllProperties();
    }
}
