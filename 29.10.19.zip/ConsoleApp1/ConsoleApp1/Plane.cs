﻿using System;

namespace ConsoleApp1
{
    class Plane
    {
        public byte EnginesCount { get; private set; }
        public int MaxHeight { get; set; }
        public int CurrentHeight { get; set; }

        public Plane  (int maxHeight, byte enginesCount)
        {
            MaxHeight = maxHeight;
            EnginesCount = enginesCount;
            CurrentHeight = 0;
            Console.WriteLine("It's a plane, welcome aboard!");
        }

        public void WriteAllProperties()
        {
            Console.WriteLine($"EnginesCount:   {EnginesCount} \n " +
                $"CurrentHeight:   {CurrentHeight} \n" +
                $"MaxHeight:   {MaxHeight}");
        }
    }
}
