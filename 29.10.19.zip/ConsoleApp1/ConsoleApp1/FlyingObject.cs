﻿using System;
namespace ConsoleApp1
{
    abstract class FlyingObject
    {

        public int MaxHeight { get; private set; }
        public int CurrentHeight { get; private set; }

        public void TakeUpper(int delta)
        {
            if (delta <= 0)
            {
                throw new ArgumentOutOfRangeException("ArgumentOutOfRangeException");
            }
            else if (CurrentHeight + delta > MaxHeight)
            {
                CurrentHeight = MaxHeight;
            }
            else
            {
                CurrentHeight = CurrentHeight + delta;
            }
        }

        public void TakeLower(int delta)
        {
            if (delta <= 0)
            {
                throw new ArgumentOutOfRangeException();
            }
            else if (CurrentHeight - delta > 0)
            {
                CurrentHeight = CurrentHeight - delta;
            }
            else if (CurrentHeight - delta == 0)
            {
                CurrentHeight = 0;
            }
            else if (CurrentHeight - delta < 0)
            {
                throw new InvalidOperationException("Crash!");
            }
        }
    }
}
