﻿using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
namespace ConsoleApp3
{
	class Program
	{
		private const string ConnectionString =
			"Server = tcp:shadow-art.database.windows.net, 1433; " +
			"Initial Catalog = reminder; " +
			"Persist Security Info = False; " +
			"User ID=app_user@shadow-art; " +
			"Password=XCrzJjTRqX43uzaEpJNj; " +
			"Encrypt=True;";
		static void Main(string[] args)
		{
			using var connection = new SqlConnection(ConnectionString);
			connection.Open();

			using var command = connection.CreateCommand();
			command.CommandType = CommandType.Text;
			command.CommandText = "SELECT COUNT(*) FROM Product";
			var result = command.ExecuteScalar();

			Console.WriteLine($"Count from product table: {result}");
		}
	}

	public interface IProductRepository
	{
		int GetCount();
		List<Product> GetAll();

	}
	public class Product
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public decimal Price { get; set; }

		public Product(
			int id,
			string name,
			decimal price
			)
		{
			Id = id;
			Name = name;
			Price = price;
		}
	}

	public class ProductRepository : IProductRepository
	{
		private readonly string _connection;
		public ProductRepository(string connection)
		{
			_connection = connection;
		}
		public List<Product> GetAll()
		{
			using var connection = CreateConnection();
			using var command = connection.CreateCommand();

			command.CommandType = CommandType.Text;
			command.CommandText = "SELECT [Id], [Name], [Price] FROM [Product] ORDER BY [Name];";

			using var reader = command.ExecuteReader();

			var result = new List<Product>();

			if (!reader.HasRows)
			{
				return result;
			}

			var idIndex = reader.GetInt32("Id");
			var nameIndex = reader.GetString("Name");
			var priceIndex = (decimal)reader.GetDouble("Price");
			while (reader.Read())
			{
				//1st option
				var id = reader.GetInt32("Id");
				var name = reader.GetString("Name");
				var price = (decimal)reader.GetDouble("Price");

				//2nd option
				var idIndex = reader.GetOrdinal("Id");
				var nameIndex = reader.GetOrdinal("Name");
				var id2 = reader.GetInt32(idIndex);
				var name2 = reader.GetString(nameIndex);
				var price2 = (decimal)reader.GetDouble(priceIndex);

				var product = new Product(id, name, price);
				result.Add(product);
			}

			return result;
		}

		
		public int GetCount()
		{
			using var connection = CreateConnection();
			using var command = connection.CreateCommand();

			command.CommandType = CommandType.Text;
			command.CommandText = "SELECT COUNT(*) FROM Product";
			var result = command.ExecuteScalar();
			return (int)result;
		}
		private SqlConnection CreateConnection()
		{
			var connection = new SqlConnection(_connection);
			connection.Open();
			return connection;
		}
	}
}
