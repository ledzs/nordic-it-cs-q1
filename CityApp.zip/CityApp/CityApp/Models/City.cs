﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CityApp.Models
{
	public class City
	{
		public Guid Id { get; set; }
		public string Name { get; set; }
		public int Population { get; set; }
		public string Description { get; set; }

		public City(
			string name,
			string description,
			int population)
		{
			Id = Guid.NewGuid();
			Name = name;
			Population = population;
			Description = description;
		}

	}
}
