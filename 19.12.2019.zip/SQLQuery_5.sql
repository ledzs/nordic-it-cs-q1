CREATE OR ALTER PROCEDURE pr_CreateProduct (
    @p_category NVARCHAR (250),
    @p_product NVARCHAR (250)
)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @categoryId UNIQUEIDENTIFIER;
    DECLARE @productId UNIQUEIDENTIFIER = NEWID();

    SELECT @categoryId = CategoryId
        EXEC pr_CreateCategory @p_category = @p_category;

    INSERT INTO Products([Id], [CategoryId], [Name])
    VALUES (@productId, @categoryId, @p_product);


END

EXEC pr_CreateProduct
    @p_category = 'Mobile',
    @p_product = 'Samsung Galaxy 10';
--доделать
