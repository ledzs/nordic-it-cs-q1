CREATE TABLE [Products] (
    [Id] UNIQUEIDENTIFIER NOT NULL PRIMARY KEY CLUSTERED,
    [CategoryId] UNIQUEIDENTIFIER NOT NULL,
    [Name] NVARCHAR(250) NOT NULL

    FOREIGN KEY ([CategoryId]) REFERENCES [Category]([Id])
                ON UPDATE NO ACTION
                ON DELETE NO ACTION

);
GO

CREATE UNIQUE INDEX UX_Product_Name ON[Products]([Name]);

ALTER TABLE [Products]
    ADD CONSTRAINT FK_Category_Id FOREIGN KEY ([CategoryId])
            REFERENCES [Category]([Id])
                ON UPDATE NO ACTION
                ON DELETE NO ACTION;

SELECT * FROM [Products];

INSERT INTO [Products]([Id], [CategoryId], [Name])
VALUES (NEWID(), '0a97ab97-20ce-465d-adc1-a196b34dbc49', 'Iphone');

--Guid CategryId
DECLARE @CategoryId UNIQUEIDENTIFIER;
PRINT 'The value is' + COALESCE('NULL', CONVERT(VARCHAR(36), @CategoryId));
GO

--Guid CategryId = Guid.Parse("d8383ef4-7ef2-4546-a964-e5561eb3f3a7");
DECLARE @CategoryId UNIQUEIDENTIFIER = 'd8383ef4-7ef2-4546-a964-e5561eb3f3a7';
PRINT 'The value is' + COALESCE(CAST(@CategoryId AS VARCHAR(36)), 'NULL');