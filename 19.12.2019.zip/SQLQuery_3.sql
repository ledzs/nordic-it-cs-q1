-- ФУНКЦИИ И ХРАНИМЫЕ ПРОЦЕДУРЫ
--Функция которая принимает некоторую категорию и возвращает идентификатор, выполняет поиск по точному совпадению...

--Guid fn_FindCategory(string p_category)

CREATE OR ALTER FUNCTION fn_FindCategory (
    @p_category NVARCHAR(250) 
)

RETURNS UNIQUEIDENTIFIER
BEGIN
    DECLARE @categoryId UNIQUEIDENTIFIER;

    SELECT  @categoryId = [Id] 
        FROM [Category] 
    WHERE [Name] = @p_category;

    IF @categoryId IS NULL
    BEGIN
        SELECT TOP 1
            @categoryId = [Id]
        FROM [Category]
        WHERE [Name] LIKE '%' + @p_category + '%'
        ORDER BY [Name];
    END

    RETURN @categoryId;
END;
GO

SELECT * FROM Category
SELECT [e_kotegov_schema].fn_FindCategory('Computer');