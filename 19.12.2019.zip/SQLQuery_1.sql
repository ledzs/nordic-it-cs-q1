--Comments
--UNIQUEIDENTIFIER same as Guid

DROP TABLE [Category];

CREATE TABLE Category (
    [Id] UNIQUEIDENTIFIER NOT NULL,
    [Name] NVARCHAR(250) NOT NULL,
    PRIMARY KEY CLUSTERED(Id)
);



INSERT INTO Category([Id], [Name]) 
VALUES  (NEWID(), 'Mobile Phone'),
        (NEWID(), 'Laptop'),
        (NEWID(), 'Tablet')
;

INSERT INTO Category([Id], [Name])
SELECT NEWID(), 'Laptop top';

SELECT [Name] FROM Category;

SELECT * FROM Category;

UPDATE [Category]
    SET [Name] = 'Tablet'
WHERE [Id] = '819bff6c-ab08-44e7-8ba6-9f4699be15dc';

--Запретить ду6лирование в колонке Name, ПОЧИСТИТЬ ТАБЛИЦУ
CREATE UNIQUE INDEX UX_Table_Name 
    ON [Category]([Name]);

    DELETE FROM [Category]
    WHERE [Name] = 'Tablet';

--очистить таблицу
TRUNCATE TABLE [Category];

--DESC сортировка по убыванию ASC по возрастанию
SELECT * 
FROM [Category]
ORDER BY [Name] DESC;

--TOP 1 количество строк для сортировки
SELECT TOP 1 
    *
FROM [Category]
ORDER BY [Name] DESC;

SELECT
    *
FROM [Category]
ORDER BY [Name] DESC
OFFSET 2 ROWS
FETCH NEXT 1 ROWS ONLY;

SELECT * FROM Category 
WHERE [Name] LIKE '%laptop%';