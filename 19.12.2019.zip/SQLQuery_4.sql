--Возвращает Ид существующей категории или новой, если такой нет

CREATE OR ALTER PROCEDURE pr_CreateCategory (
    @p_category NVARCHAR(250) 

)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @categoryId UNIQUEIDENTIFIER = [e_kotegov_schema].fn_FindCategory(@p_category);

    IF @categoryId IS NULL
    BEGIN
        SET @p_category = NEWID()

        INSERT INTO Category([Id], [Name])
        VALUES (@categoryId, @p_category);
    END

    SELECT @categoryId AS CategoryId;
END;
GO

SELECT * FROM [Category]
EXEC [e_kotegov_schema].pr_CreateCategory @p_category = 'a';
