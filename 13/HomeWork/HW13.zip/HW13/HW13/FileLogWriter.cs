﻿using System;
using System.IO;

namespace HW13
{
    public class FileLogWriter : ILogWritter
    {
        public void LogError(string message)
        {
            string Message = message;
            File.AppendAllText("C:/StudioLog/Log", $"\n{DateTime.Now.ToString("yyyy-MM-ddTHH:mm:sszzz")}\tError\t{Message}");
        }

        public void LogInfo(string message)
        {
            string Message = message;
            File.AppendAllText("C:/StudioLog/Log", $"\n{DateTime.Now.ToString("yyyy-MM-ddTHH:mm:sszzz")}\tInfo\t{Message}");
        }

        public void LogWarning(string message)
        {
            string Message = message;
            File.AppendAllText("C:/StudioLog/Log", $"\n{DateTime.Now.ToString("yyyy-MM-ddTHH:mm:sszzz")}\tWarning\t{Message}");
        }
    }
}
