﻿using System;
using System.IO;

namespace HW13
{
    class Program
    {
        static void Main(string[] args)
        {
            var logInFile = new FileLogWriter();
            var logInConsole = new ConsoleLogWriter();
            logInFile.LogError("crash");
            logInFile.LogInfo("nothing wrong");
            logInFile.LogWarning("alarm!");

            logInConsole.LogInfo("nothing wrong");

            Console.ReadKey();
        }
    }
}
