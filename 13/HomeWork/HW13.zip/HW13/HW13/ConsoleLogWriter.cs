﻿using System;
namespace HW13
{
    public class ConsoleLogWriter : ILogWritter
    {
        public void LogError(string message)
        {
            string Message = message;
            Console.WriteLine($"\n{DateTime.Now.ToString("yyyy-MM-ddTHH:mm:sszzz")}\tError\t{Message}");
        }

        public void LogInfo(string message)
        {
            string Message = message;
            Console.WriteLine($"\n{DateTime.Now.ToString("yyyy-MM-ddTHH:mm:sszzz")}\tInfo\t{Message}");
        }

        public void LogWarning(string message)
        {
            string Message = message;
            Console.WriteLine($"\n{DateTime.Now.ToString("yyyy-MM-ddTHH:mm:sszzz")}\tWarning\t{Message}");
        }
    }
}
