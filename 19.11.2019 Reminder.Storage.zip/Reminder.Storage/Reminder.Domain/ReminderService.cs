﻿using System;
using System.Threading;
using Reminder.Storage;


namespace Reminder.Domain
{
	public class CreateReminderModel
	{
		public string contactId { get; set; }
		public string message { get; set; }
		public DateTimeOffset messageDate { get; set; }
	}

	public class ReminderService
	{
		public event EventHandler<ReminderModelEventArgs> ReminderItemFired;

		private readonly IReminderStorage _storage;
		private readonly Timer _timer;
		public ReminderService(IReminderStorage storage)
		{
			_storage = storage;
			_timer = new Timer(OnCreatedItemTirmerTick, null, TimeSpan.MinValue, TimeSpan.FromSeconds(1))
			{

			};
		}

		public void Create(CreateReminderModel model)
		{
			var item = new ReminderItem(
			Guid.NewGuid(),
			model.contactId,
			model.message,
			model.messageDate);

			_storage.Create(item);
		}

		private void OnCreatedItemTirmerTick(object state)
		{
			var datetime = DateTimeOffset.Now;
			var filter = new ReminderItemFilter()

			var items = _storage.FindBy(filter);

			foreach (var item in items)
			{
				
				_storage.Update(item.ReadyToSend());
			}
		}
		private void OnReadyItemTimerTick(object state)
		{
			var filter = new ReminderItemFilter()
				.Ready();
			var items = _storage.FindBy(filter);
			foreach (var item in items)
			{
				_storage.Update(item.ReadyToSend());
			}
		}

		public void Start()
		{
			//
		}
	}
}
