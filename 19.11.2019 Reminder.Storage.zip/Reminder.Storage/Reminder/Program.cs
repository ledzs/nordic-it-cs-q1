﻿using System;
using Reminder.Domain;
using Reminder.Storage;
using Reminder.Storage.Memory;

namespace Reminder
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Reminder Notifier.. starting");

			var storage = new ReminderStorage();
			var service = new ReminderService(storage);


			Console.ReadKey();
		}
	}
}
