﻿using System;


namespace classwork07._11._19
{
	class Program
	{
		
		static void Main(string[] args)
		{

			double radius = 54;
			Circle circle = new Circle(radius);
			Console.WriteLine($"For the circle with radius {radius} \n" +
				$" Perimeter: {circle.Calculate(r => 2 * Math.PI * r)}, \n" +
				$" Area: {circle.Calculate(r => Math.Pow(Math.PI * r, 2))}, \n" +
				$" Diameter: {circle.Calculate(r => r * 2)}");
			Console.ReadKey();
			
		}

		
		public static double Perimeter(double raduis)
		{
			double perimeter = 2 * Math.PI * r;
			return perimeter;
		}

		public static double Area(double radius)
		{
			double area = Math.Pow(Math.PI * radius, 2);
			return area;
		}
		
	}

}
