﻿using System;

namespace Reminder.Sender
{
	public class Class1
	{
	}
}
