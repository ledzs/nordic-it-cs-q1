﻿using System;

namespace Reminder.Receiver
{
	public class Class1
	{
	}
}
