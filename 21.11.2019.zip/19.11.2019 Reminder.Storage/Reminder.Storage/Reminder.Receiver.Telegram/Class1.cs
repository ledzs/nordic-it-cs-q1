﻿using System;

namespace Reminder.Receiver.Telegram
{
	public class Class1
	{
	}
}
