﻿using System;
using Telegram.Bot;
namespace Reminder.Sender.Telegram
{
	public class Class1
	{
	}
}
