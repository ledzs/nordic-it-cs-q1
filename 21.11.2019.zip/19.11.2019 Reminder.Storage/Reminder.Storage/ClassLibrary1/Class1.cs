﻿using System;

namespace Reminder.Domain
{
	public class Class1
	{
	}
}
