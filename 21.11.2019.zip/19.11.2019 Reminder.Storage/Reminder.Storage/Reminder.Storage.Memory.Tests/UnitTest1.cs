using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace Reminder.Storage.Memory.Tests
{
	public class ReminderStorageTests
	{
		//WhenUnit_IfCondition_ShouldExpectedResult

		[Test]
		public void Create_IfEmptyStorage_ShouldFindItemById()
		{
			//Arrange
			var item = new ReminderItem(
				Guid.NewGuid(),
				"123",
				"Some text",
				DateTimeOffset.Now);
			var storage = new ReminderStorage();

			//Act
			storage.Create(item);

			//Assert
			var result = storage.FindById(item.Id);
			Assert.AreEqual(item.Id, result.Id);
		}

		[Test]
		public void WhenCreate_IfNullSpecified_ShouldThrowException()
		{
			var storage = new ReminderStorage();

			Assert.Catch<ArgumentNullException>(() => 
			storage.Create(null));
		}

		public void WhenCreate_IfExistsElementWithKey_ShouldThrowException()
		{
			//Arrange
			var item = new ReminderItem(
				Guid.NewGuid(),
				"123",
				"Some text",
				DateTimeOffset.Now);
			var storage = new ReminderStorage(
				item
				);

			Assert.Catch<ArgumentException>(() => storage.Create(item)
			);
		}

		[Test]
		public void WhenFindByDateTime_IfEmptyDateTimeSpecifeid_ShouldThrowException()
		{
			var storage = new ReminderStorage();
			Assert.Catch<ArgumentException>(() => storage.FindByDateTime(default)
			);
		}

		[Test]
		public void WhenFindByDateTime_IfSpecifeidDateTime_ShouldFilterByIt()
		{
			
			var storage = new ReminderStorage(
				CreateReminderItem(messageDate: DateTimeOffset.Parse("12.11.2019 14:28:00.120")
				));
			var result = storage.FindByDateTime(DateTimeOffset.Parse("12.11.2019 14:30:00.00")
				);

			Assert.IsNotEmpty(result);
		}

		private ReminderItem CreateReminderItem(
			)


	}
}