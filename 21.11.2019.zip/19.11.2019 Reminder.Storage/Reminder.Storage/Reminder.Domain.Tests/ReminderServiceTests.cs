using NUnit.Framework;
using Reminder.Storage.Memory;
using System;
using System.Threading;

namespace Reminder.Domain.Tests
{
	public class ReminderServiceTests
	{
		[Test]
		public void ItemSent_WhenReminderItemAdded_ShoulRaiseEvent()
		{
			var parameters = new ReminderServiceParameters(
				
				);

			var storage = new ReminderStorage();
			var service = new ReminderService(storage);
			var eventRaised = false;

			service.ItemSent += (sender, args) => eventRaised = true;

			service.Create(
				new CreateReminderModel("ContactId", "Message",DateTimeOffset.UtcNow)
				);
			Thread.Sleep(TimeSpan.FromSeconds(4));
			Assert.IsTrue(eventRaised);
		}

	}
}