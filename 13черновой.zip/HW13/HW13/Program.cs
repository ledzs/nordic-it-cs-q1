﻿using System;
using System.IO;

namespace HW13
{
    enum MessageType { Error = 1, Info, Warning };
    partial class Program
    {
        static void Main(string[] args)
        {
            var logInFile = new FileLogWriter("C:/StudioLog/Log.log");
            var logInConsole = new ConsoleLogWriter();

            var multipleLogWriter = new MultipleLogWriter(logInFile, logInConsole);

            multipleLogWriter.LogError("ErrorMessage");
            multipleLogWriter.LogInfo("InfoMessage");
            multipleLogWriter.LogWarning("WarningMessage");

            Console.ReadKey();
        }
    }
}
