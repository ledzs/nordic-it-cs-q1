﻿using System;

namespace ConsoleApp10
{
	class Program
	{
		static void Main(string[] args)
		{
			Circle circle = new Circle(1.5);
			Console.WriteLine($"For the circle with radius 1.5 \n" +
				$" {circle.Calculate(Perimeter)}, \n" +
				$" {circle.Calculate(Area)}");
			Console.ReadKey();
		}

		public static double Perimeter(double radius)
		{
			double perimeter = 2 * Math.PI * radius;
			return perimeter;
		}

		public static double Area(double radius)
		{
			double area = Math.Pow(Math.PI * radius, 2);
			return area;
		}
	}
}
