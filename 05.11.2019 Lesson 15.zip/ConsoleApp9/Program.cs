﻿using System;

namespace ConsoleApp9
{
	class Program
	{
		static void Main(string[] args)
		{
			Guid guid = Guid.NewGuid();
			var account1 = new Account<int>(001, "Id001");
			var account2 = new Account<string>("002", "Id002");
			var account3 = new Account<Guid>(guid, "Id003");

			account1.WriteProperties();
			account2.WriteProperties();
			account3.WriteProperties();
			Console.ReadKey();
		}
	}
}
