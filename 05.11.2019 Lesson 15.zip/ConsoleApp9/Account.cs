﻿using System;
namespace ConsoleApp9
{
	class Account<T>
	{
		public T Id { get;private set; }
		public string Name { get; set; }

		public Account(T id, string name)
		{
			Id = id;
			Name = name;
		}
		public void WriteProperties()
		{
			Console.WriteLine($"ID: {Id}, Name: {Name}");
		}

	}
}
