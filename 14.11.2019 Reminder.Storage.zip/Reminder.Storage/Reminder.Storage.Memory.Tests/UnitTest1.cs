using System;
using NUnit.Framework;

namespace Reminder.Storage.Memory.Tests
{
	public class ReminderStorageTests
	{
		//WhenUnit_IfCondition_ShouldExpectedResult

		[Test]
		public void Create_IfEmptyStorage_ShouldFindItemById()
		{
			//Arrange
			var item = new ReminderItem(
				Guid.NewGuid(),
				"123",
				"Some text",
				DateTimeOffset.Now);
			var storage = new ReminderStorage();

			//Act
			storage.Create(item);

			//Assert
			var result = storage.FindById(item.Id);
			Assert.AreEqual(item.Id, result.Id);
		}

		[Test]
		public void WhenCreate_IfNullSpecified_ShouldThrowException()
		{
			var storage = new ReminderStorage();

			Assert.Catch<ArgumentNullException>(() => 
			storage.Create(null));
		}

		public void WhenCreate_IfExistsElementWithKey_ShouldThrowException()
		{
			//Arrange
			var item = new ReminderItem(
				Guid.NewGuid(),
				"123",
				"Some text",
				DateTimeOffset.Now);
			var storage = new ReminderStorage(
				item
				);

			Assert.Catch<ArgumentException>(() => storage.Create(item)
			);
		}
	}
}